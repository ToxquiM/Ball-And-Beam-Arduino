This is an old version of my quad code.  [Go here for the latest version.](https://github.com/bolandrm/rmb_multicopter)
